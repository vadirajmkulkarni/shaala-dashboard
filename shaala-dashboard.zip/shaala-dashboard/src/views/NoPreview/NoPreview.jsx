import React, { Component } from 'react';

export default class NoPreview extends Component {

  render() {
    return (
      <h3>No preview available.</h3>
    );
  }
}
